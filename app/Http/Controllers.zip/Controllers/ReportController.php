<?php

namespace App\Http\Controllers;

use App\Models\Agency;
use App\Models\Attendance;
use App\Models\Journal;
use App\Models\Mentor;
use App\Models\Monitoring;
use App\Models\Region;
use App\Models\Student;
use App\Models\StudentMentor;
use App\Models\Teacher;
use Illuminate\Http\Request;
use Yajra\DataTables\Facades\DataTables;
use Barryvdh\DomPDF\Facade\Pdf;

class ReportController extends Controller
{
    public function regionReportReview(Request $request){
        if ($request->ajax()) {
            $regions = Region::all();

            return DataTables::collection($regions)->make(true);
        }

        return view('report-menu.region-report',[
            'title' => 'Laporan Wilayah Magang',
            'menu' => 'region-report'
        ]);
    }

    public function downloadRegionReport(Request $request){
        $regions = Region::select('*');
                                       
        if ($request->has('name')) {
            $regions->where('name', 'like', "%{$request->get('name')}%");
        }

        if ($request->has('city')) {
            $regions->where('city', 'like', "%{$request->get('city')}%");
        }

        $data = [
            'data' => $regions->get(),
            'title' => "Daftar Wilayah Magang"
        ];

        $pdf = Pdf::loadView('report.region', $data);
    
        return $pdf->stream('Daftar Wilayah Magang.pdf');
    }

    public function agencyReportReview(Request $request){
        if ($request->ajax()) {
            $agencies = Agency::select('agencies.*', 'regions.name as region')
                                ->join('regions', 'regions.id', '=', 'agencies.region_id')
                                ->get();

            return DataTables::collection($agencies)->make(true);
        }

        return view('report-menu.agency-report',[
            'title' => 'Laporan Industri Magang',
            'menu' => 'agency-report'
        ]);
    }

    public function downloadAgencyReport(Request $request){
        $agencies = Agency::select('agencies.*', 'regions.name as region')
                                ->join('regions', 'regions.id', '=', 'agencies.region_id');
                                       
        if ($request->has('region')) {
            $agencies->where('regions.name', 'like', "%{$request->get('region')}%");
        }

        if ($request->has('name')) {
            $agencies->where('agencies.name', 'like', "%{$request->get('name')}%");
        }

        if ($request->has('leader')) {
            $agencies->where('leader', 'like', "%{$request->get('leader')}%");
        }

        if ($request->has('nip')) {
            $agencies->where('nip', 'like', "%{$request->get('nip')}%");
        }

        if ($request->has('phone')) {
            $agencies->where('phone', 'like', "%{$request->get('phone')}%");
        }

        if ($request->has('address')) {
            $agencies->where('address', 'like', "%{$request->get('address')}%");
        }

        if ($request->has('characteristic')) {
            $agencies->where('characteristic', 'like', "%{$request->get('characteristic')}%");
        }

        $agencies = $agencies->get();
        $data = [
            'data' => $agencies,
            'title' => "Daftar Industri Magang"
        ];

        $pdf = Pdf::loadView('report.agency', $data);
    
        return $pdf->stream('Daftar Industri.pdf');
    }

    public function studentReportReview(Request $request){
        if ($request->ajax()) {
            $students = Student::select('students.*', 'grade_classes.grade as grade', 'departments.name as department', 'users.email as email')
                            ->join('grade_classes', 'students.grade_class_id', '=', 'grade_classes.id')
                            ->join('departments', 'grade_classes.department_id', '=', 'departments.id')
                            ->join('users', 'students.user_id', '=', 'users.id')->get();

            return DataTables::collection($students)->make(true);
        }

        return view('report-menu.student-report',[
            'title' => 'Laporan Daftar Murid',
            'menu' => 'student-report'
        ]);
    }

    public function downloadStudentReport(Request $request){
        $students = Student::select('students.*', 'grade_classes.grade as grade', 'departments.name as department', 'users.email as email')
                            ->join('grade_classes', 'students.grade_class_id', '=', 'grade_classes.id')
                            ->join('departments', 'grade_classes.department_id', '=', 'departments.id')
                            ->join('users', 'students.user_id', '=', 'users.id');
                          
                            
        if($request->name){
            $students->where('students.name', 'like', "%{$request->name}%");
        }

        if($request->nisn){
            $students->where('students.nisn', 'like', "%{$request->nisn}%");
        }
        
        if($request->grade){
            $students->where('grade_classes.grade', 'like', "%{$request->nisn}%");
        }
        
        if($request->department){
            $students->where('departments.name', 'like', "%{$request->nisn}%");  
        }
        
        if($request->email){
            $students->where('users.email', 'like', "%{$request->nisn}%");
        }

        $data = [
            'data' => $students->get(),
            'title' => "Daftar Siswa"
        ];

        $pdf = Pdf::loadView('report.student', $data);
    
        return $pdf->stream('Daftar Siswa.pdf');
    }

    public function teacherReportReview(Request $request){
        if ($request->ajax()) {
            $teachers = Teacher::select('teachers.*', 'users.email as email')
                            ->join('users', 'teachers.user_id', '=', 'users.id')->get();

            return DataTables::collection($teachers)->make(true);
        }

        return view('report-menu.teacher-report',[
            'title' => 'Laporan Daftar Murid',
            'menu' => 'teacher-report'
        ]);
    }

    public function downloadTeacherReport(Request $request){
        $teachers = Teacher::select('teachers.*', 'users.email as email')
                            ->join('users', 'teachers.user_id', '=', 'users.id');

        if($request->name){
            $teachers->where('name', 'like', "%{$request->name}%");
        }

        if($request->nip){
            $teachers->where('nip', 'like', "%{$request->nip}%");
        }

        if($request->position){
            $teachers->where('position', 'like', "%{$request->position}%");
        }

        if($request->email){
            $teachers->where('user.email', 'like', "%{$request->email}%");
        }

        $data = [
            'data' => $teachers->get(),
            'title' => "Daftar Guru"
        ];

        $pdf = Pdf::loadView('report.teacher', $data);
    
        return $pdf->stream('Daftar Guru.pdf');
    }

    public function mentorReportReview(Request $request){
        if ($request->ajax()) {
            $mentors = Mentor::select('regions.name as region', 'regions.city as city', 'users.email as email', 'teachers.nip as nip', 'teachers.name as name', 'departments.name as department')
                            ->join('teachers', 'teachers.id', '=', 'mentors.teacher_id')
                            ->join('grade_classes', 'grade_classes.id', '=', 'teachers.grade_class_id')
                            ->join('departments', 'departments.id', '=', 'grade_classes.department_id')
                            ->join('regions', 'regions.id', '=', 'mentors.region_id')
                            ->join('users', 'teachers.user_id', '=', 'users.id')->get();

            return DataTables::collection($mentors)->make(true);
        }

        return view('report-menu.mentor-report',[
            'title' => 'Laporan Daftar Guru Pembimbing',
            'menu' => 'mentor-report'
        ]);
    }

    public function downloadMentorReport(Request $request){
        $mentors = Mentor::select('regions.name as region', 'regions.city as city', 'users.email as email', 'teachers.nip as nip', 'teachers.name as name', 'departments.name as department')
                            ->join('teachers', 'teachers.id', '=', 'mentors.teacher_id')
                            ->join('grade_classes', 'grade_classes.id', '=', 'teachers.grade_class_id')
                            ->join('departments', 'departments.id', '=', 'grade_classes.department_id')
                            ->join('regions', 'regions.id', '=', 'mentors.region_id')
                            ->join('users', 'teachers.user_id', '=', 'users.id');

        
        if($request->name){
            $mentors->where('teachers.name', 'like', "%{$request->get('name')}%");
        }

        if($request->department){
            $mentors->where('departments.name', 'like', "%{$request->get('department')}%");
        }

        if($request->nip){
            $mentors->where('teachers.nip', 'like', "%{$request->get('nip')}%");
        }

        if($request->email){
            $mentors->where('users.email', 'like', "%{$request->get('email')}%");
        }

        if($request->region){
            $mentors->where('regions.name', 'like', "%{$request->get('region')}%");
        }

        if($request->city){
            $mentors->where('regions.city', 'like', "%{$request->get('city')}%");
        }

        $data = [
            'data' => $mentors->get(),
            'title' => "Daftar Guru Pembimbing"
        ];

        $pdf = Pdf::loadView('report.mentor', $data);
    
        return $pdf->stream('Daftar Guru Pembimbing.pdf');
    }

    public function mentoringReportReview(Request $request){
        if ($request->ajax()) {
            $mentors = StudentMentor::select('teachers.name as teacher', 'teachers.nip', 'regions.city', 'regions.name as region', 'students.name as student', 'students.nisn', 'departments.name as department')
                                    ->join('mentors', 'mentors.id', '=', 'student_mentors.mentor_id')
                                    ->join('teachers', 'teachers.id', '=', 'mentors.teacher_id')
                                    ->join('regions', 'regions.id', '=', 'mentors.region_id')
                                    ->join('students', 'students.id', '=', 'student_mentors.student_id')
                                    ->join('grade_classes', 'students.grade_class_id', '=', 'grade_classes.id')
                                    ->join('departments', 'grade_classes.department_id', '=', 'departments.id')
                                    ->get();

            return DataTables::collection($mentors)->make(true);
        }

        return view('report-menu.mentoring-report',[
            'title' => 'Laporan Daftar Guru Pembimbing Siswa',
            'menu' => 'mentoring-report'
        ]);
    }

    public function downloadMentoringReport(Request $request){
        $mentors = StudentMentor::select('student_mentors.*', 'teachers.name as teacher', 'teachers.nip', 'regions.city', 'regions.name as region', 'students.name as student', 'students.nisn', 'departments.name as department')
                                    ->join('mentors', 'mentors.id', '=', 'student_mentors.mentor_id')
                                    ->join('teachers', 'teachers.id', '=', 'mentors.teacher_id')
                                    ->join('regions', 'regions.id', '=', 'mentors.region_id')
                                    ->join('students', 'students.id', '=', 'student_mentors.student_id')
                                    ->join('grade_classes', 'students.grade_class_id', '=', 'grade_classes.id')
                                    ->join('departments', 'grade_classes.department_id', '=', 'departments.id');

        if ($request->region) {
            $request->where('regions.name', 'like', "%{$request->get('region')}%");
        }

        if ($request->teacher) {
            $request->where('teachers.name', 'like', "%{$request->get('teacher')}%");
        }

        if ($request->nip) {
            $request->where('teachers.nip', 'like', "%{$request->get('nip')}%");
        }

        if ($request->student) {
            $request->where('students.name', 'like', "%{$request->get('student')}%");
        }

        if ($request->nisn) {
            $request->where('students.nisn', 'like', "%{$request->get('nisn')}%");
        }

        if ($request->department) {
            $request->where('departments.name', 'like', "%{$request->get('department')}%");
        }

        $data = [
            'data' => $mentors->get(),
            'title' => "Daftar Guru Pembimbing Siswa"
        ];

        $pdf = Pdf::loadView('report.mentoring', $data);
    
        return $pdf->stream('Daftar Guru Pembimbing Siswa.pdf');
    }

    public function journalReportReview(Request $request){
        if ($request->ajax()) {
            $journals = Journal::select('journals.*', 'agencies.name as agency', 'students.name as student', 'regions.name as region', 'departments.name as department')
                                    ->join('application_letters', 'application_letters.id' ,'=', 'journals.application_letter_id')
                                    ->join('agencies', 'agencies.id' ,'=', 'application_letters.agency_id')
                                    ->join('regions', 'regions.id' ,'=', 'agencies.region_id')
                                    ->join('students', 'students.id' ,'=', 'journals.student_id')
                                    ->join('grade_classes', 'grade_classes.id' ,'=', 'students.grade_class_id')
                                    ->join('departments', 'departments.id' ,'=', 'grade_classes.department_id')
                                    ->get();

            return DataTables::collection($journals)->make(true);
        }

        return view('report-menu.journal-report',[
            'title' => 'Laporan Jurnal kegiatan',
            'menu' => 'journal-report'
        ]);
    }

    public function downloadJournalReport(Request $request){
        $journals = Journal::select('journals.*', 'agencies.name as agency', 'students.name as student', 'regions.name as region' , 'departments.name as department')
                                    ->join('application_letters', 'application_letters.id' ,'=', 'journals.application_letter_id')
                                    ->join('agencies', 'agencies.id' ,'=', 'application_letters.agency_id')
                                    ->join('regions', 'regions.id' ,'=', 'agencies.region_id')
                                    ->join('students', 'students.id' ,'=', 'journals.student_id')
                                    ->join('grade_classes', 'grade_classes.id' ,'=', 'students.grade_class_id')
                                    ->join('departments', 'departments.id' ,'=', 'grade_classes.department_id');

        if ($request->region) {
            $journals->where('regions.name', 'like', "%{$request->get('region')}%");
        }

        if ($request->student) {
            $journals->where('students.name', 'like', "%{$request->get('student')}%");
        }

        if ($request->date) {
            $journals->where('journals.date', $request->get('date'));
        }

        if ($request->agency) {
            $journals->where('agencies.name', 'like', "%{$request->get('agency')}%");
        }

        if ($request->activity) {
            $journals->where('journals.activity', 'like', "%{$request->get('activity')}%");
        }

        $data = [
            'data' => $journals->get(),
            'title' => "laporan Jurnal Kegiatan Siswa"
        ];

        $pdf = Pdf::loadView('report.journal-all', $data);
    
        return $pdf->stream('Laporan Jurnal Kegiatan.pdf');
    }

    public function studentMonitoringReportReview(Request $request){
        if ($request->ajax()) {
            $monitorings = Monitoring::select('monitorings.*', 'teachers.name as teacher', 'regions.name as region', 'agencies.name as agency')
                                    ->join('teachers', 'teachers.id', '=', 'monitorings.teacher_id')
                                    ->join('application_letters', 'application_letters.id', '=', 'monitorings.application_letter_id')
                                    ->join('agencies', 'agencies.id', '=', 'application_letters.agency_id')
                                    ->join('regions', 'regions.id', '=', 'agencies.region_id')
                                    ->get();

            return DataTables::collection($monitorings)->make(true);
        }

        return view('report-menu.student-mentoring',[
            'title' => 'Laporan Bimbingan',
            'menu' => 'monitoring-report'
        ]);
    }

    public function downloadStudentMonitoringReport(Request $request){
        $monitorings = Monitoring::select('monitorings.*', 'teachers.name as teacher', 'regions.name as region', 'agencies.name as agency')
                                    ->join('teachers', 'teachers.id', '=', 'monitorings.teacher_id')
                                    ->join('application_letters', 'application_letters.id', '=', 'monitorings.application_letter_id')
                                    ->join('agencies', 'agencies.id', '=', 'application_letters.agency_id')
                                    ->join('regions', 'regions.id', '=', 'agencies.region_id');

        if ($request->date) {
            $monitorings->where('date', $request->get('date'));
        }

        if ($request->teacher) {
            $monitorings->where('teachers.name', 'like', "%{$request->get('teacher')}%");
        }

        if ($request->region) {
            $monitorings->where('regions.name', 'like', "%{$request->get('region')}%");
        }

        if ($request->agency) {
            $monitorings->where('agencies.name', 'like', "%{$request->get('agency')}%");
        }

        if ($request->description) {
            $monitorings->where('monitorings.description', 'like', "%{$request->get('description')}%");
        }

        $data = [
            'data' => $monitorings->get(),
            'title' => "Laporan Bimbingan Siswa"
        ];

        $pdf = Pdf::loadView('report.monitoring-all', $data);
    
        return $pdf->stream('Laporan Bimbingan Siswa.pdf');
    }

    public function attendanceReportReview(Request $request){
        if ($request->ajax()) {
            $attendances = Attendance::select('attendances.*', 'students.name as student', 'agencies.name as agency')
                                    ->join('application_letters', 'application_letters.id', '=', 'attendances.application_letter_id')
                                    ->join('agencies', 'agencies.id', '=', 'application_letters.agency_id')
                                    ->join('students', 'students.id', '=', 'attendances.student_id')
                                    ->get();

            return DataTables::collection($attendances)->addColumn('status', function($attendance) {
                if($attendance->isPermit){
                    return "Izin";
                }else if($attendance->isAlpha){
                    return "Alpha";
                }else if($attendance->isSick){
                    return "Sakit";
                }else{
                    return "Hadir";
                }
            })->editColumn('in', function($attendance) {
                return date("H:m", strtotime($attendance->in));
            })->editColumn('out', function($attendance) {
                return date("H:m", strtotime($attendance->out));
            })->make(true);
        }

        return view('report-menu.attendance-report',[
            'title' => 'Laporan Absensi Siswa',
            'menu' => 'attendance-report'
        ]);
    }

    public function downloadAttendanceReport(Request $request){
        $attendances = Attendance::select('attendances.*', 'students.name as student', 'agencies.name as agency')
                                    ->join('application_letters', 'application_letters.id', '=', 'attendances.application_letter_id')
                                    ->join('agencies', 'agencies.id', '=', 'application_letters.agency_id')
                                    ->join('students', 'students.id', '=', 'attendances.student_id');

        if ($request->date) {
            $attendances->where('date', $request->get('date'));
        }

        if ($request->agency) {
            $attendances->where('agencies.name', 'like', "%{$request->get('agency')}%");
        }

        if ($request->student) {
            $attendances->where('students.name', 'like', "%{$request->get('student')}%");
        }

        if($request->in){
            $attendances->where('attendances.in', date("H:m", strtotime($request->in)));
        }

        if($request->out){
            $attendances->where('attendances.in', date("H:m", strtotime($request->out)));
        }

        if ($request->description) {
            $attendances->where('attendances.description', 'like', "%{$request->get('description')}%");
        }

        if (strtolower($request->status) == "alpha") {
            $attendances->where('attendances.isAlpha', true);
        }

        if (strtolower($request->status) == 'izin') {
            $attendances->where('attendances.isPermit', true);
        }

        if (strtolower($request->status) == "sakit") {
            $attendances->where('attendances.isSick', true);
        }

        if (strtolower($request->status) == "hadir") {
            $attendances->where('attendances.isAlpha', false);
            $attendances->where('attendances.isPermit', false);
            $attendances->where('attendances.isSick', false);
        }

        $data = [
            'data' => $attendances->get(),
            'title' => "Laporan Absensi Siswa"
        ];

        $pdf = Pdf::loadView('report.attendance-all', $data);
    
        return $pdf->stream('Laporan Absensi Siswa.pdf');
    }
}
