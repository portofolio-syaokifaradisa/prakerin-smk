<?php

namespace App\Http\Controllers;

use App\Http\Requests\LoginRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    public function index(){
        return view('auth.login.index',[
            'title' => "Login"
        ]);
    }

    public function login(LoginRequest $request){
        $validated_request = $request->validated();

        if (Auth::attempt(['email' => $validated_request['email'], 'password' => $validated_request['password']])) {
            return redirect(Route('home'));
        }else{
            return redirect(Route('login'))->with('error', 'login gagal, Silahkan Coba Lagi!');
        }
    }

    public function forgotPassword(){

    }

    public function resetPassword(Request $request){

    }
}
